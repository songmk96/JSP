package com.test;

public class Student {
	// 멤버 변수
	private String name;
	private int sno;

	// 생성자
	public Student(String name, int sno) {
		this.name = name;
		this.sno = sno;
	}

	// getter&setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}
}
