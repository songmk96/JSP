package com.test;

import java.util.List;

public class DeptDaoTest {

	public static void main(String[] args) {
		DeptDao deptDao = new DeptDao();
		Dept dept = deptDao.selectDept(40);
		System.out.println(dept.getDeptId() 
				+ ", " + dept.getDeptName()
				+ ", " + dept.getLocId());
//		deptDao.insertDept(new Dept(70, "숙박팀", 100));
//		deptDao.updateDept(new Dept(70, "숙박팀2", 200));
//		deptDao.deleteDept(70);
//		List<Dept> depts = deptDao.selectAllDept();
//		for(Dept dept : depts) {
//			System.out.println(dept.getDeptId() 
//					+ ", " + dept.getDeptName()
//					+ ", " + dept.getLocId());
//		}		
	}
}
