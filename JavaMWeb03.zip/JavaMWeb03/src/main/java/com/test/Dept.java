package com.test;
// DO(Data Object, Entity Object..)
public class Dept {
	private int deptId;
	private String deptName;
	private int locId;
	public Dept(int deptId, String deptName, int locId) {
		this.deptId = deptId; this.deptName = deptName;
		this.locId = locId;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getLocId() {
		return locId;
	}
	public void setLocId(int locId) {
		this.locId = locId;
	}
}
