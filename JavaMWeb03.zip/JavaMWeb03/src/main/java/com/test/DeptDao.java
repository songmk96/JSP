package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//interface Dao<T>{
//	List<T> select();
//	T selectDept(int id);
//	void insertDept(T d);
//	void updateDept(T d);	
//	void deleteDept(int d);
//}
public class DeptDao {
	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:orcl";
	private String jdbcUsername = "user2";
	private String jdbcPassword = "1234";

	private static final String SELECT_ALL_DEPT_SQL = "select * from dept";
	private static final String SELECT_DEPT_SQL = "select * from dept where dept_id = ?";
	private static final String INSERT_DEPT_SQL = "insert into dept values(?,?,?)";
	private static final String UPDATE_DEPT_SQL = "update dept set dept_name = ?, loc_id = ? where dept_id = ?";
	private static final String DELETE_DEPT_SQL = "delete from dept where dept_id = ?";

	public DeptDao() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public List<Dept> selectAllDept() {
		List<Dept> depts = new ArrayList<Dept>();
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_DEPT_SQL);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println(preparedStatement);
			while (rs.next()) {
				int deptId = rs.getInt("dept_id");
				String deptName = rs.getString("dept_name");
				int locId = rs.getInt("loc_id");
				depts.add(new Dept(deptId, deptName, locId));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return depts;
	}

	public Dept selectDept(int id) {
		Dept dept = null;
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_DEPT_SQL);
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			System.out.println(preparedStatement);
			while (rs.next()) {
				int deptId = rs.getInt("dept_id");
				String deptName = rs.getString("dept_name");
				int locId = rs.getInt("loc_id");
				dept = new Dept(deptId, deptName, locId);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dept;
	}

	public void insertDept(Dept dept) {
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_DEPT_SQL);
			preparedStatement.setInt(1, dept.getDeptId());
			preparedStatement.setString(2, dept.getDeptName());
			preparedStatement.setInt(3, dept.getLocId());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void updateDept(Dept dept) {
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_DEPT_SQL);
			preparedStatement.setString(1, dept.getDeptName());
			preparedStatement.setInt(2, dept.getLocId());
			preparedStatement.setInt(3, dept.getDeptId());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void deleteDept(int id) {
		Connection connection = getConnection();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(DELETE_DEPT_SQL);
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
