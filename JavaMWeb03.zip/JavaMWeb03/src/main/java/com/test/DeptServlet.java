package com.test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DeptServlet extends HttpServlet {
	private DeptDao deptDao;
	@Override
	public void init() throws ServletException {
		this.deptDao = new DeptDao();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		System.out.println(action);
		switch(action) {
			case "create" :
				insertDept(request, response);
			default:
				listDept(request, response);
				break;
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	private void insertDept(HttpServletRequest request, 
			HttpServletResponse response)  throws ServletException, IOException {
		int deptId = Integer.parseInt(request.getParameter("deptId"));
		String deptName = request.getParameter("deptName");
		int locId = Integer.parseInt(request.getParameter("locId"));
		Dept dept = new Dept(deptId, 
				deptName, locId);
		deptDao.insertDept(dept);
		listDept(request, response);
	}
	private void listDept(HttpServletRequest request, 
			HttpServletResponse response)  throws ServletException, IOException {
		List<Dept> listDept = deptDao.selectAllDept();
		request.setAttribute("listDept", listDept);
		RequestDispatcher dispatcher = 
				request.getRequestDispatcher("dept-list.jsp");
		dispatcher.forward(request, response);
	}
	

}
