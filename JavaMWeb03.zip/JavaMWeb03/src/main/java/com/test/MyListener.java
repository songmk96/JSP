package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class MyListener implements ServletContextListener {
    public MyListener() {}

	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:orcl";
	private String jdbcUsername = "user3";
	private String jdbcPassword = "1234";
    
    public void contextDestroyed(ServletContextEvent sce) { }

    public void contextInitialized(ServletContextEvent sce) { 
    	Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, 
					jdbcUsername, 
					jdbcPassword);
			ServletContext ctx = sce.getServletContext();
			ctx.setAttribute("mycon", connection);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
	
}
